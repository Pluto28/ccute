module Main where

import GHC.IO.Exception (ExitCode)
import System.Directory
import System.FilePath
import System.Process

main :: IO ExitCode
main =
  let filename = "yep.c"
   in preprocess filename
        >> assembly filename
        >> assemble filename

preprocess :: String -> IO ExitCode
preprocess filename =
  let output = replaceExt filename ".i"
   in do
        (_, _, _, procHndl) <-
          createProcess
            ( proc
                "gcc"
                ["-E", "-P", filename, "-o", output]
            )
        waitForProcess procHndl

assembly :: String -> IO ExitCode
assembly filename =
  let source = replaceExt filename ".i"
   in let output = replaceExt filename ".s"
       in do
            (_, _, _, procHndl) <-
              createProcess
                ( proc
                    "gcc"
                    ["-S", source, "-o", output]
                )
            exit <- waitForProcess procHndl
            removeFile source
            return exit

assemble :: String -> IO ExitCode
assemble filename =
  let source = replaceExt filename ".s"
   in let output = replaceExt filename ""
       in do
            (_, _, _, procHndl) <-
              createProcess
                ( proc
                    "gcc"
                    [source, "-o", output]
                )
            exit <- waitForProcess procHndl
            removeFile source
            return exit

replaceExt :: String -> String -> String
replaceExt filename newext = noExt ++ newext
  where
    (noExt, _) = splitExtension filename
